package il.co.jb.infra.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonAddToCartApprovePage extends AbstractPage {

	private static final By addToCartApproveText = By.xpath("//*[@id=\"huc-v2-order-row-confirm-text\"]/h1");
	private static final By cartButton = By.id("hlb-view-cart-announce");
	
	
	
	public AmazonAddToCartApprovePage(WebDriver driver) {
		super(driver);
	}
	
	public boolean isAdded() {
		if (driver.findElement(addToCartApproveText).getText().equals("Added to Cart"))
		{
			return true;
		}
		return false;
	}
	
	public AmazonAddToCartApprovePage clickOnCartButton() {
		driver.findElement(cartButton).click();
		return this;
	}	
	
	
}
