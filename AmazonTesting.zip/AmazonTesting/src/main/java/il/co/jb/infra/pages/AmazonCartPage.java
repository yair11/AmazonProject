package il.co.jb.infra.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonCartPage extends AbstractPage {
	
	private static final By deletetButton = By.xpath("//*[@class=\"a-row sc-list-item sc-list-item-border sc-java-remote-feature\"]/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input");
	private static final By deleteApproveText = By.xpath("//*[@class=\"a-row sc-list-item sc-list-item-border sc-java-remote-feature\"]/div[3]/div[1]/span/a");
		
	
	
	public AmazonCartPage(WebDriver driver) {
		super(driver);
	}
	
		
	public AmazonCartPage clickOnDeleteButton() {
		driver.findElement(deletetButton).click();
		return this;
	}	
	
	public boolean isDeletedFromCart() {
		if (driver.findElement(deleteApproveText).getText().equals("\r\n" + 
				"            was removed from Shopping Cart.\r\n" + 
				"            \r\n" + 
				"        "))
		{
			return true;
		}
		return false;
	}
	
	
}
