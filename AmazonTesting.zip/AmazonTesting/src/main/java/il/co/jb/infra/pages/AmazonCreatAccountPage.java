package il.co.jb.infra.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonCreatAccountPage extends AbstractPage {
	
	private static final By nameInput = By.id("ap_customer_name");
	private static final By emailInput = By.id("ap_email");
	private static final By passwordInput = By.id("ap_password");
	private static final By repasswordInput = By.id("ap_password_check");	
	private static final By createAccountButton = By.id("continue");
	
	public AmazonCreatAccountPage(WebDriver driver) {
		super(driver);
	}
	
	public AmazonCreatAccountPage writeName(String name) {
		driver.findElement(nameInput).sendKeys(name);
		return this;
	}

	public AmazonCreatAccountPage writeEmail(String email) {
		driver.findElement(emailInput).sendKeys(email);
		return this;
	}
	
	public AmazonCreatAccountPage writePassword(String password) {
		driver.findElement(passwordInput).sendKeys(password);
		return this;
	}
	
	public AmazonCreatAccountPage writerepassword(String password) {
		driver.findElement(repasswordInput).sendKeys(password);
		return this;
	}
	
	public AmazonCreatAccountPage clickCreatAccountInButton() {
		driver.findElement(createAccountButton).click();
		return this;
	}
}
