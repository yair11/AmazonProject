package il.co.jb.infra.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AmazonItemDetailsPage extends AbstractPage {

	private static final By itemSizeButton = By.id("dropdown_selected_size_name");	
	private static final By listOfSIzes = By.xpath("//*[@class=\"a-popover a-dropdown a-dropdown-common a-declarative\"]/div/div/ul");
 	private static final By addToCartButton = By.id("add-to-cart-button");
 	private static final By itemSize = By.tagName("li");
 	
 	
	
	public AmazonItemDetailsPage(WebDriver driver) {
		super(driver);
	}
	

	public AmazonItemDetailsPage clickSizeButton() throws InterruptedException {
		driver.findElement(itemSizeButton).click();
		List<WebElement> sizes = driver.findElement(listOfSIzes).findElements(itemSize);
		for (WebElement size : sizes) {
			if(size.isEnabled() && size.isDisplayed() && !size.getText().equals("Select")) {
				size.click();
				break;
			}
		}
		return this;
	}	
	
	public AmazonItemDetailsPage clickAddToCartButton() throws InterruptedException {
		Thread.sleep(10000);
		driver.findElement(addToCartButton).click();
		return this;
	}	
}
