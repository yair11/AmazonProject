package il.co.jb.infra.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonLandingPage extends AbstractPage {

	private static final By searchBox = By.id("twotabsearchtextbox");
	private static final By searchButton = By.cssSelector("input[value='Go']");
 	private static final By signInLink = By.id("nav-link-accountList");
	private static final By cartButton = By.id("nav-cart");

	
	public AmazonLandingPage(WebDriver driver) {
		super(driver);
	}
	
	public void writeToSearchBox(String searchTerm) {
		driver.findElement(searchBox).sendKeys(searchTerm);
	}
	
	public void clickSearchButton() {
		driver.findElement(searchButton).click();
	}
	
	public AmazonSignInPage clickSignInLink() {
		driver.findElement(signInLink).click();
		return new AmazonSignInPage(driver);
	}
	
	public AmazonLandingPage clickOnCartButton() {
		driver.findElement(cartButton).click();
		return this;
	}	
	
}
