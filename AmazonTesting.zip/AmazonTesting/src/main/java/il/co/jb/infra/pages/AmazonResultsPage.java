package il.co.jb.infra.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonResultsPage extends AbstractPage {

	private static final By firstItemElement = By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[1]/div/div/div/div/div/div[2]/div[2]/div/div[1]/h2/a/span");
	
	
	public AmazonResultsPage(WebDriver driver) {
		super(driver);
	}

	
	
	public AmazonResultsPage clickOnFirstItemElement() {
		driver.findElement(firstItemElement).click();
		return this;
	}
}
