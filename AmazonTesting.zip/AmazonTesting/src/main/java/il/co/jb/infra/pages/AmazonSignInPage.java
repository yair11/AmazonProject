package il.co.jb.infra.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonSignInPage extends AbstractPage {

	private static final By emailInput = By.id("ap_email");
	private static final By passwordInput = By.id("ap_password");
	private static final By signInButton = By.id("signInSubmit");
	private static final By creatAccountButton = By.id("createAccountSubmit");
	
	public AmazonSignInPage(WebDriver driver) {
		super(driver);
	}

	public AmazonSignInPage writeEmail(String email) {
		driver.findElement(emailInput).sendKeys(email);
		return this;
	}
	
	public AmazonSignInPage writePassword(String password) {
		driver.findElement(passwordInput).sendKeys(password);
		return this;
	}
	
	public AmazonSignInPage clickSignInButton() {
		driver.findElement(signInButton).click();
		return this;
	}
	
	public AmazonSignInPage clickCreatAccountButton() {
		driver.findElement(creatAccountButton).click();
		return this;
	}
}
