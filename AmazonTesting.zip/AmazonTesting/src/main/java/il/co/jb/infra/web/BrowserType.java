package il.co.jb.infra.web;

public enum BrowserType
 {

	CHROME,
	FIREFOX,
	INTERNET_EXPLORER;
}
