package il.co.jb.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import il.co.jb.infra.web.BrowserType;
import il.co.jb.infra.web.WebDriverFactory;

public abstract class AbstractTest {

	protected WebDriver driver;
	
	@BeforeMethod
	public void before() {
		
		System.out.println("Inside @BeforeMethod");
		
		if (driver == null) {
			driver = WebDriverFactory.getDriver(BrowserType.CHROME);
		}
	}
	
	
}
