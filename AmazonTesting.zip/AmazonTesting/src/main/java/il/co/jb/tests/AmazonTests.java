package il.co.jb.tests;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import il.co.jb.infra.pages.AmazonAddToCartApprovePage;
import il.co.jb.infra.pages.AmazonCartPage;
import il.co.jb.infra.pages.AmazonItemDetailsPage;
import il.co.jb.infra.pages.AmazonLandingPage;
import il.co.jb.infra.pages.AmazonResultsPage;
import il.co.jb.infra.pages.AmazonSignInPage;

public class AmazonTests extends AbstractTest {	
	
	
	@BeforeMethod
    public void beforeClass() {
		driver.get("http://www.amazon.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

	@Test(priority=1)	
	public void testSignIn() throws InterruptedException {		
		
		AmazonLandingPage amazonLandingPage = new AmazonLandingPage(driver);
		amazonLandingPage.clickSignInLink();		
		AmazonSignInPage amazonSignInPage = new AmazonSignInPage(driver);
		amazonSignInPage.writeEmail("");
		amazonSignInPage.writePassword("");
		amazonSignInPage.clickSignInButton();
	}
	
	
	
	@Test(priority=2)
	public void testAddToCartButton() throws InterruptedException {
	
		
		AmazonLandingPage amazonLandingPage = new AmazonLandingPage(driver);		
		amazonLandingPage.writeToSearchBox("shirts");
		amazonLandingPage.clickSearchButton();
		
		AmazonResultsPage amazonResultsPage = new AmazonResultsPage(driver);
		amazonResultsPage.clickOnFirstItemElement();
		
		AmazonItemDetailsPage amazonItemDetailsPage = new AmazonItemDetailsPage(driver);
		amazonItemDetailsPage.clickSizeButton();
		
		amazonItemDetailsPage.clickAddToCartButton();
		
		AmazonAddToCartApprovePage amazonAddToCartApprovePage = new AmazonAddToCartApprovePage(driver);		
		assertTrue(amazonAddToCartApprovePage.isAdded());				
		
	}
	
	@Test(priority=3)
	public void testDeleteFromCartButton() throws InterruptedException {
	
		AmazonLandingPage amazonLandingPage = new AmazonLandingPage(driver);		
		amazonLandingPage.clickOnCartButton();
		
		AmazonCartPage amazonCartPage = new AmazonCartPage(driver);
		amazonCartPage.clickOnDeleteButton();
		assertTrue(amazonCartPage.isDeletedFromCart());
			
	}	


}

